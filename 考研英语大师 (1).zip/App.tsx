import React, { useState, useEffect } from 'react';
import { searchArticle, analyzeText } from './services/geminiService';
import { Article, SentenceAnalysis } from './types';
import ArticleView from './components/ArticleView';
import AnalysisPanel from './components/AnalysisPanel';
import { Search, GraduationCap, Menu, X, CheckSquare, BookOpen, AlertTriangle, AlertCircle } from 'lucide-react';

const INITIAL_ARTICLE: Article = {
  title: "考研英语阅读助手 (点击任意句子进行分析)",
  paragraphs: [
    "欢迎来到您的AI考研英语智能助手。本应用旨在为您提供高度仿真的考研英语阅读体验。",
    "点击左侧“搜索同源外刊”，输入感兴趣的话题（如“人工智能”、“经济全球化”等），AI将为您全网搜索真实的权威外刊文章（如《经济学人》、《卫报》等）。",
    "点击文中的任意句子，即可获取包含音标、发音、语法的深度解析。本工具利用先进的生成式AI技术，助您精准突破考研长难句。"
  ],
  questions: []
};

const App: React.FC = () => {
  const [article, setArticle] = useState<Article>(INITIAL_ARTICLE);
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // Analysis State
  const [analysis, setAnalysis] = useState<SentenceAnalysis | null>(null);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [activeTab, setActiveTab] = useState<'study' | 'quiz'>('study');

  // Generation Form State
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState<'English I' | 'English II'>('English II');

  // Error & Status State
  const [missingKey, setMissingKey] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!process.env.API_KEY) {
      setMissingKey(true);
    }
  }, []);

  // Auto-hide error message after 5 seconds
  useEffect(() => {
    if (errorMsg) {
      const timer = setTimeout(() => setErrorMsg(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMsg]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (missingKey) {
      setErrorMsg("请先配置 API Key 才能使用搜索功能。");
      return;
    }
    if (!topic.trim()) return;

    setSidebarOpen(false); // Close mobile sidebar
    setLoading(true);
    setAnalysis(null);
    setErrorMsg(null);
    setActiveTab('study');
    
    try {
      const newArticle = await searchArticle(topic, difficulty);
      setArticle(newArticle);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "搜索文章失败，请检查网络或 Key 额度。");
    } finally {
      setLoading(false);
    }
  };

  const handleSentenceClick = async (sentence: string) => {
    // Only analyze in study mode
    if (activeTab === 'quiz') return;
    
    if (missingKey) {
      setErrorMsg("请先配置 API Key 才能使用分析功能。");
      setSidebarOpen(true); 
      return;
    }

    setLoadingAnalysis(true);
    setErrorMsg(null);
    try {
      const context = article.paragraphs.join(' ');
      const result = await analyzeText(sentence, context);
      setAnalysis(result);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "分析句子失败，请重试。");
    } finally {
      setLoadingAnalysis(false);
    }
  };

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden font-sans text-gray-900 relative">
      
      {/* API Key Missing Banner */}
      {missingKey && (
        <div className="absolute top-0 left-0 right-0 z-50 bg-amber-600 text-white px-4 py-3 shadow-md flex items-center justify-center gap-3 animate-in slide-in-from-top duration-300">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <div className="text-sm font-medium">
            <span className="font-bold">未检测到 API Key</span>
            <span className="mx-2 hidden sm:inline">|</span>
            <span className="block sm:inline">请在 Vercel 环境变量配置 <code className="bg-amber-800 px-1 rounded mx-1">API_KEY</code> 并点击 <strong className="underline">Redeploy</strong>。</span>
          </div>
        </div>
      )}

      {/* Global Error Toast */}
      {errorMsg && (
        <div className="absolute top-16 left-1/2 transform -translate-x-1/2 z-50 bg-red-600 text-white px-6 py-3 rounded-full shadow-lg flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-300">
          <AlertCircle className="w-5 h-5" />
          <span className="text-sm font-medium">{errorMsg}</span>
          <button onClick={() => setErrorMsg(null)} className="ml-2 hover:bg-red-700 rounded-full p-0.5">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sidebar (Generation Controls) */}
      <div className={`fixed inset-y-0 left-0 z-30 w-80 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static md:flex-shrink-0 flex flex-col ${missingKey ? 'pt-12' : ''}`}>
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-8 h-8 text-indigo-400" />
            <h1 className="text-xl font-bold tracking-tight">考研英语大师</h1>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="md:hidden">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 flex-1 overflow-y-auto">
          <div className="mb-8">
            <h2 className="text-xs uppercase text-slate-500 font-bold tracking-wider mb-4">搜索同源外刊</h2>
            <form onSubmit={handleSearch} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">话题 / 领域</label>
                <input 
                  type="text" 
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  disabled={missingKey}
                  placeholder="例如：人工智能、西方文化、美国经济..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-md px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">考试难度</label>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    type="button"
                    disabled={missingKey}
                    onClick={() => setDifficulty('English II')}
                    className={`px-3 py-2 text-sm rounded-md border ${difficulty === 'English II' ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-700 text-slate-400 hover:bg-slate-800'} disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    英语二
                  </button>
                  <button 
                     type="button"
                     disabled={missingKey}
                     onClick={() => setDifficulty('English I')}
                     className={`px-3 py-2 text-sm rounded-md border ${difficulty === 'English I' ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-700 text-slate-400 hover:bg-slate-800'} disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    英语一
                  </button>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={loading || !topic || missingKey}
                className="w-full flex items-center justify-center gap-2 bg-indigo-500 hover:bg-indigo-400 text-white font-medium py-2.5 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    搜索文章
                  </>
                )}
              </button>
            </form>
          </div>

          <div>
             <h2 className="text-xs uppercase text-slate-500 font-bold tracking-wider mb-4">使用说明：可点击句子分析</h2>
             <ul className="text-sm text-slate-400 space-y-4">
               <li className="flex items-start gap-3">
                 <span className="text-indigo-400 font-mono font-bold shrink-0 mt-0.5">01</span>
                 <span className="leading-relaxed">输入话题，搜索真实发表的外刊文章。</span>
               </li>
               <li className="flex items-start gap-3">
                 <span className="text-indigo-400 font-mono font-bold shrink-0 mt-0.5">02</span>
                 <span className="leading-relaxed">
                   点击文章中的<span className="text-indigo-300 font-semibold">任意句子</span>，获取音标、翻译及语法分析。
                 </span>
               </li>
               <li className="flex items-start gap-3">
                 <span className="text-indigo-400 font-mono font-bold shrink-0 mt-0.5">03</span>
                 <span className="leading-relaxed">切换到“真题实战”模式进行答题练习。</span>
               </li>
             </ul>
          </div>
        </div>
        
        <div className="p-4 border-t border-slate-800 text-xs text-slate-600 text-center">
          Powered by Gemini 2.5 Flash with Search Grounding
        </div>
      </div>

      {/* Main Content Area */}
      <div className={`flex-1 flex flex-col h-full relative transition-all ${missingKey ? 'pt-12' : ''}`}>
        {/* Mobile Header */}
        <div className="md:hidden h-14 bg-white border-b border-gray-200 flex items-center justify-between px-4">
          <button onClick={() => setSidebarOpen(true)} className="text-gray-600">
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-bold text-gray-800">考研英语大师</span>
          <div className="w-6" /> {/* Spacer */}
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Article View (Scrollable) */}
          <div className={`flex-1 overflow-y-auto bg-gray-50 transition-all duration-300 ${activeTab === 'study' ? 'block' : 'hidden md:block'}`}>
            <ArticleView 
              article={article} 
              onSentenceClick={handleSentenceClick} 
              isLoading={loading} 
            />
          </div>

          {/* Right Panel (Analysis/Quiz) */}
          <div className="w-full md:w-[400px] bg-white border-l border-gray-200 flex flex-col md:relative fixed inset-0 z-20 md:z-auto md:translate-y-0 transition-transform duration-300 transform translate-y-full md:flex">
             {/* Tab Toggle (Visible mostly on desktop or when panel is active) */}
             <div className="flex border-b border-gray-200">
                <button 
                  onClick={() => setActiveTab('study')}
                  className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === 'study' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  <BookOpen className="w-4 h-4" />
                  精读分析
                </button>
                <button 
                  onClick={() => setActiveTab('quiz')}
                  className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === 'quiz' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  <CheckSquare className="w-4 h-4" />
                  真题实战 ({article.questions.length})
                </button>
             </div>

             <div className="flex-1 overflow-hidden relative">
                <AnalysisPanel 
                  analysis={analysis} 
                  loadingAnalysis={loadingAnalysis} 
                  questions={article.questions}
                  showQuiz={activeTab === 'quiz'}
                />
             </div>
          </div>
        </div>

        {/* Mobile Floating Action Button to toggle Panel */}
        <div className="md:hidden fixed bottom-6 right-6 z-50">
          <button 
            onClick={() => setActiveTab(activeTab === 'study' ? 'quiz' : 'study')}
            className="bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
          >
             {activeTab === 'study' ? <CheckSquare className="w-6 h-6" /> : <BookOpen className="w-6 h-6" />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default App;