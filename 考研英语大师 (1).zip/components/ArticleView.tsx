import React from 'react';
import { Article } from '../types';
import { ExternalLink } from 'lucide-react';

interface ArticleViewProps {
  article: Article;
  onSentenceClick: (sentence: string) => void;
  isLoading: boolean;
}

const ArticleView: React.FC<ArticleViewProps> = ({ article, onSentenceClick, isLoading }) => {
  // Helper to split paragraph into sentences roughly for clicking
  const splitSentences = (text: string) => {
    return text.match( /[^.!?]+[.!?]+["']?|[^.!?]+$/g ) || [text];
  };

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto p-8 space-y-8 animate-pulse">
        <div className="h-8 bg-gray-200 rounded w-3/4 mx-auto"></div>
        <div className="space-y-4">
          <div className="h-4 bg-gray-200 rounded w-full"></div>
          <div className="h-4 bg-gray-200 rounded w-full"></div>
          <div className="h-4 bg-gray-200 rounded w-5/6"></div>
        </div>
        <div className="space-y-4">
          <div className="h-4 bg-gray-200 rounded w-full"></div>
          <div className="h-4 bg-gray-200 rounded w-4/5"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-8 md:p-12 bg-paper min-h-full shadow-sm">
      <h1 className="text-3xl md:text-4xl font-serif font-bold text-ink mb-4 text-center leading-tight">
        {article.title}
      </h1>

      {/* Source Link */}
      {article.sourceUrl && (
        <div className="flex justify-center mb-8">
           <a 
             href={article.sourceUrl} 
             target="_blank" 
             rel="noopener noreferrer"
             className="flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-3 py-1 rounded-full transition-colors"
           >
             <ExternalLink className="w-3 h-3" />
             来源: {article.source || "Web Source"}
           </a>
        </div>
      )}
      
      <div className="space-y-6 font-serif text-lg md:text-xl text-ink leading-loose">
        {article.paragraphs.map((para, pIdx) => (
          <p key={pIdx} className="indent-8 text-justify">
            {splitSentences(para).map((sentence, sIdx) => (
              <span
                key={sIdx}
                className="hover:bg-highlight cursor-pointer transition-colors rounded px-0.5"
                onClick={(e) => {
                  e.stopPropagation();
                  onSentenceClick(sentence.trim());
                }}
              >
                {sentence}{' '}
              </span>
            ))}
          </p>
        ))}
      </div>

      <div className="mt-12 pt-8 border-t border-gray-300 text-center text-gray-500 text-sm font-sans">
        全文结束 • 点击句子查看详细语法分析
      </div>
    </div>
  );
};

export default ArticleView;