export enum AppState {
  IDLE = 'IDLE',
  LOADING_ARTICLE = 'LOADING_ARTICLE',
  READING = 'READING',
  ANALYZING = 'ANALYZING',
}

export interface Vocabulary {
  word: string;
  meaning: string;
  partOfSpeech: string;
  phonetic?: string;
}

export interface Question {
  id: number;
  question: string;
  options: string[]; // [A, B, C, D]
  answer: number; // 0-3
  explanation: string;
}

export interface Article {
  title: string;
  paragraphs: string[];
  source?: string;
  sourceUrl?: string;
  questions: Question[];
}

export interface SentenceAnalysis {
  original: string;
  translation: string;
  grammarBreakdown: string[];
  keyVocabulary: Vocabulary[];
  difficultyLevel: 'Easy' | 'Medium' | 'Hard';
}

export interface GenerationRequest {
  topic: string;
  difficulty: 'English I' | 'English II';
}