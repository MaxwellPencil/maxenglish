import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Article, SentenceAnalysis } from "../types";

// Initialize Gemini Client
// We ensure the API key is present. If not, the app will likely fail when calling methods, 
// but we rely on the environment setup instructions.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = "gemini-2.5-flash";

// Schema for generating an article
const articleSchemaStructure = {
  title: "String",
  paragraphs: ["String (Paragraph 1)", "String (Paragraph 2)", "String (Paragraph 3)", "String (Paragraph 4)"],
  questions: [
    {
      id: 1,
      question: "String",
      options: ["String (Option A)", "String (Option B)", "String (Option C)", "String (Option D)"],
      answer: 0,
      explanation: "String (Chinese explanation)"
    }
  ]
};

// Schema for analyzing a sentence
const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    original: { type: Type.STRING },
    translation: { type: Type.STRING, description: "Accurate Chinese translation" },
    grammarBreakdown: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of grammatical structures and syntax analysis in Chinese."
    },
    keyVocabulary: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          word: { type: Type.STRING },
          phonetic: { type: Type.STRING, description: "IPA phonetic transcription (e.g. /həˈləʊ/)" },
          partOfSpeech: { type: Type.STRING },
          meaning: { type: Type.STRING, description: "Chinese meaning in context" }
        }
      }
    },
    difficultyLevel: { type: Type.STRING, enum: ["Easy", "Medium", "Hard"] }
  },
  required: ["translation", "grammarBreakdown", "keyVocabulary", "difficultyLevel"]
};

/**
 * Helper to safely extract JSON from a potential Markdown response
 */
const extractJSON = (text: string): any => {
  let jsonString = text;

  // 1. Prioritize extracting from markdown code blocks
  // Matches ```json ... ``` or just ``` ... ```
  const codeBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  if (codeBlockMatch && codeBlockMatch[1]) {
    jsonString = codeBlockMatch[1];
  } else {
    // 2. Fallback: Find the substring between the first '{' and the last '}'
    const firstOpen = text.indexOf('{');
    const lastClose = text.lastIndexOf('}');
    if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
      jsonString = text.substring(firstOpen, lastClose + 1);
    }
  }

  try {
    return JSON.parse(jsonString);
  } catch (e) {
    console.error("JSON Parse failed. Raw text:", text);
    throw new Error("Could not parse valid JSON from AI response. Please try again.");
  }
};

export const searchArticle = async (topic: string, type: 'English I' | 'English II'): Promise<Article> => {
  // We utilize Google Search to find real content, ensuring authenticity.
  const prompt = `
    Task: Search for and retrieve a REAL, existing English article from the web about: "${topic}".
    
    CRITICAL: 
    1. Do NOT write a fake article. 
    2. You MUST use the Google Search tool to find an actual published article.
    3. Use the content of that article.
    
    Source Preference: Reputable sources like The Economist, New York Times, The Guardian, BBC, CNN, Nature, or Science.
    Difficulty Level: ${type} (English I = Academic/Complex, English II = General/Business).
    
    Instructions:
    1. Find a suitable article.
    2. Extract 4-5 paragraphs (approx 400-500 words total) from the actual text.
    3. Create 5 reading comprehension questions based on this text.
    4. Provide the questions in English, options in English, but explanations in CHINESE.
    
    Output Format:
    Return ONLY the raw JSON object. Do not wrap it in markdown code blocks if possible, or ensure the markdown is clean.
    The JSON must match this structure exactly:
    ${JSON.stringify(articleSchemaStructure, null, 2)}
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        // Search Grounding Enabled
        tools: [{ googleSearch: {} }],
        // Note: responseSchema and responseMimeType are NOT allowed when using tools.
        systemInstruction: "You are a rigid JSON generator. You must output only valid JSON matching the requested schema.",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const articleData = extractJSON(text) as Article;

    // Extract Source URL from Grounding Metadata
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (groundingChunks && groundingChunks.length > 0) {
      // Find the first web URI available
      const webSource = groundingChunks.find(c => c.web?.uri);
      if (webSource?.web) {
        articleData.source = webSource.web.title;
        articleData.sourceUrl = webSource.web.uri;
      }
    }

    return articleData;
  } catch (error) {
    console.error("Failed to generate article:", error);
    throw error;
  }
};

export const analyzeText = async (text: string, context: string): Promise<SentenceAnalysis> => {
  const prompt = `
    Analyze the following sentence from a Kaoyan reading passage.
    Sentence: "${text}"
    Context (surrounding text): "${context.substring(0, 200)}..."

    Provide:
    1. Accurate Chinese translation (信达雅).
    2. Detailed grammar/syntax analysis in CHINESE.
    3. Key vocabulary words (advanced/exam-relevant).
       IMPORTANT: For each word, you MUST provide the IPA Phonetic Symbol (phonetic) and Chinese definition.
    4. Difficulty rating.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: "You are a professional Kaoyan English tutor. Explain clearly in Chinese.",
      }
    });

    const output = response.text;
    if (!output) throw new Error("No analysis received");
    
    // Even with JSON mode, it's safer to use the helper in case of small glitches
    return extractJSON(output) as SentenceAnalysis;
  } catch (error) {
    console.error("Failed to analyze text:", error);
    throw error;
  }
};