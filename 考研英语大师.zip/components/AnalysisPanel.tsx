import React from 'react';
import { SentenceAnalysis, Question } from '../types';
import { BookOpen, AlertCircle, CheckCircle, XCircle, BrainCircuit, Volume2 } from 'lucide-react';

interface AnalysisPanelProps {
  analysis: SentenceAnalysis | null;
  loadingAnalysis: boolean;
  questions: Question[];
  showQuiz: boolean;
}

const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ analysis, loadingAnalysis, questions, showQuiz }) => {
  const [selectedOptions, setSelectedOptions] = React.useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = React.useState<Record<number, boolean>>({});

  const handleOptionSelect = (qId: number, optionIdx: number) => {
    setSelectedOptions(prev => ({ ...prev, [qId]: optionIdx }));
    setShowExplanation(prev => ({ ...prev, [qId]: true }));
  };

  const getDifficultyLabel = (level: string) => {
    switch(level) {
      case 'Easy': return '简单';
      case 'Medium': return '中等';
      case 'Hard': return '困难';
      default: return level;
    }
  };

  const playPronunciation = (word: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.lang = 'en-US'; 
      utterance.rate = 0.9;
      window.speechSynthesis.cancel(); // Stop any previous
      window.speechSynthesis.speak(utterance);
    }
  };

  if (showQuiz) {
    return (
      <div className="h-full overflow-y-auto p-6 bg-white border-l border-gray-200">
        <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <BrainCircuit className="w-5 h-5 text-indigo-600" />
          阅读理解自测
        </h2>
        {questions.length === 0 ? (
          <p className="text-gray-500 text-center mt-10">暂无题目，请先生成文章。</p>
        ) : (
          <div className="space-y-8">
            {questions.map((q, idx) => {
              const isAnswered = selectedOptions[q.id] !== undefined;
              const isCorrect = selectedOptions[q.id] === q.answer;
              
              return (
                <div key={q.id} className="p-4 rounded-lg bg-gray-50 border border-gray-100">
                  <p className="font-medium text-gray-800 mb-3">{idx + 1}. {q.question}</p>
                  <div className="space-y-2">
                    {q.options.map((opt, optIdx) => {
                      let btnClass = "w-full text-left p-3 rounded text-sm transition-colors border ";
                      if (isAnswered) {
                        if (optIdx === q.answer) {
                          btnClass += "bg-green-100 border-green-300 text-green-800";
                        } else if (selectedOptions[q.id] === optIdx) {
                          btnClass += "bg-red-100 border-red-300 text-red-800";
                        } else {
                          btnClass += "bg-white border-gray-200 opacity-50";
                        }
                      } else {
                        btnClass += "bg-white border-gray-200 hover:bg-indigo-50 hover:border-indigo-200";
                      }

                      return (
                        <button
                          key={optIdx}
                          onClick={() => !isAnswered && handleOptionSelect(q.id, optIdx)}
                          disabled={isAnswered}
                          className={btnClass}
                        >
                          <span className="font-bold mr-2">{String.fromCharCode(65 + optIdx)}.</span>
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                  {showExplanation[q.id] && (
                    <div className={`mt-3 p-3 rounded text-sm ${isCorrect ? 'bg-green-50 text-green-800' : 'bg-amber-50 text-amber-900'}`}>
                      <div className="flex items-center gap-2 font-semibold mb-1">
                        {isCorrect ? <CheckCircle className="w-4 h-4"/> : <XCircle className="w-4 h-4"/>}
                        答案解析:
                      </div>
                      {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto bg-white border-l border-gray-200 flex flex-col">
      <div className="p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-600" />
          深度解析
        </h2>
        
        {loadingAnalysis ? (
          <div className="flex flex-col items-center justify-center py-12 space-y-4">
            <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
            <p className="text-sm text-gray-500 animate-pulse">正在分析语法结构与核心词汇...</p>
          </div>
        ) : analysis ? (
          <div className="space-y-6">
            {/* Selected Sentence */}
            <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
              <p className="text-sm font-serif text-indigo-900 leading-relaxed italic">
                "{analysis.original}"
              </p>
            </div>

            {/* Translation */}
            <div>
              <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-2">参考译文</h3>
              <p className="text-gray-800 leading-relaxed">{analysis.translation}</p>
            </div>

            {/* Vocabulary */}
            <div>
              <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-3">核心词汇</h3>
              <div className="space-y-3">
                {analysis.keyVocabulary.map((vocab, i) => (
                  <div key={i} className="flex flex-col pb-3 border-b border-gray-100 last:border-0 gap-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-indigo-700 text-lg">{vocab.word}</span>
                      {vocab.phonetic && (
                        <span className="text-xs text-gray-500 font-mono bg-gray-100 px-1.5 py-0.5 rounded">
                          {vocab.phonetic}
                        </span>
                      )}
                      <button 
                        onClick={() => playPronunciation(vocab.word)}
                        className="p-1 hover:bg-gray-100 rounded-full text-indigo-500 transition-colors"
                        title="Play pronunciation"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex items-baseline gap-2 text-sm">
                      <span className="text-xs font-semibold text-gray-500 italic uppercase tracking-wider">[{vocab.partOfSpeech}]</span>
                      <span className="text-gray-800">{vocab.meaning}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Grammar */}
            <div>
              <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-2">长难句语法拆解</h3>
              <ul className="space-y-2">
                {analysis.grammarBreakdown.map((point, i) => (
                  <li key={i} className="flex gap-2 text-sm text-gray-700">
                    <span className="text-indigo-400 mt-1">•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

             {/* Difficulty Badge */}
             <div className="pt-4 flex justify-end">
                <span className={`px-3 py-1 rounded-full text-xs font-bold border
                  ${analysis.difficultyLevel === 'Hard' ? 'bg-red-50 text-red-600 border-red-200' :
                    analysis.difficultyLevel === 'Medium' ? 'bg-yellow-50 text-yellow-600 border-yellow-200' :
                    'bg-green-50 text-green-600 border-green-200'
                  }`}>
                  难度等级: {getDifficultyLabel(analysis.difficultyLevel)}
                </span>
             </div>
          </div>
        ) : (
          <div className="text-center py-20 px-6">
            <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">点击文章中的任意句子<br/>获取详细的语法分析和翻译</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnalysisPanel;